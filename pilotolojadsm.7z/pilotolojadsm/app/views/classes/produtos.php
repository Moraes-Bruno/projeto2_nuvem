<?php
    echo "<h2 class='subtitulo'>Nossos Produtos</h2>";
    echo "<div class='produto'>";
    echo "<img src='../img/polo.jpg'>";
    echo '<div class="dados">';
    echo "<h3>Camisa Polo</h3>";
    echo "<p>Marca: Ralph Lauren</p>";
    echo "<p>R$ 49,90</p>";
    echo "<button class='add-carrinho' data-produto='Camisa Polo'>Adicionar ao Carrinho</button>";
    echo'</div>';
    echo "</div>";

    echo "<div class='produto'>";
    echo "<img src='../img/adidas.jpg'>";
    echo '<div class="dados">';
    echo "<h3>Tenis</h3>";
    echo "<p>Marca: Adidas</p>";
    echo "<p>R$ 300,00</p>";
    echo "<button class='add-carrinho' data-produto='Camisa Polo'>Adicionar ao Carrinho</button>";
    echo'</div>';
    echo "</div>";

    echo "<div class='produto'>";
    echo "<img src='../img/diesel.jpg'>";
    echo '<div class="dados">';
    echo "<h3>Calça</h3>";
    echo "<p>Marca: Diesel</p>";
    echo "<p>R$ 500,00</p>";
    echo "<button class='add-carrinho' data-produto='Camisa Polo'>Adicionar ao Carrinho</button>";
    echo'</div>';
    echo "</div>";
?>
