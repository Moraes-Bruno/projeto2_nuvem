<?php
    echo "<h1 class='msg'>Seja bem-vindo à nossa loja de roupas!</h1>";
    echo "<h2 class='msg'>onde estilo e conforto se encontram para criar o seu visual perfeito!</h2>";
    
    echo'<script src="../js/scripts.js"></script>'
?>
